const express = require('express')
const router = express.Router()
const { createDetalle, deleteDetalle, getDetalle } = require('./actions')

// GET by ID
router.get('/:id', getDetalle)

// POST Create a detalle
router.post('/', createDetalle)

// PUT Update a detalle's info
router.put('/:id', (req, res) => {
  res.send({})
})

// DELETE by ID
router.delete('/:id', deleteDetalle)

module.exports = router