const Detalle = require('./model')

const createDetalle = (req, res) => {
  const newDetalle = new Detalle(req.body)
  newDetalle.save((error, DetalleSaved) => {
    if (error) {
      console.error('Error saving detalle ', error)
      res.status(500).send(error)
    } else {
      res.send(DetalleSaved)
    }
  })
}

const deleteDetalle = (req, res) => {
  Detalle.findByIdAndDelete(req.params.id, (error, result) => {
    if (error) {
      res.status(500).send(error)
    } else {
      res.send('Detalle deleted successfully!')
      res.status(204)
    }
  })
}

const getDetalle = (req, res) => {
  Detalle.find({}, (error, detalles) => {
    if (error) {
      res.status(500).send(error)
    } else if (detalles) {
      res.send(detalles)
    } else {
      res.status(404).send({})
    }
  })
}

module.exports = { createDetalle, deleteDetalle, getDetalle }

