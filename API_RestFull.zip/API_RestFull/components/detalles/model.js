const mongoose = require('mongoose')
var books = mongoose.model('books')

const Detalle = mongoose.model('detalles', { idLibro: [{
    type: mongoose.Schema.Types.ObjectId,
    ref:'books' }], nombreLibro: String, ValorUnitario: Number, Cantidad: Number })

module.exports = Detalle

