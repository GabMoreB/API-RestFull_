const Venta = require('./model')

const createVenta = (req, res) => {
  const newVenta = new Venta(req.body)
  newVenta.save((error, ventaSaved) => {
    if (error) {
      console.error('Error saving venta ', error)
      res.status(500).send(error)
    } else {
      res.send(ventaSaved)
    }
  })
}

const deleteVenta = (req, res) => {
  Venta.findByIdAndDelete(req.params.id, (error, result) => {
    if (error) {
      res.status(500).send(error)
    } else {
      res.send('Venta deleted successfully!')
      res.status(204)
    }
  })
}

const getVenta = (req, res) => {
  Venta.find({}, (error, ventas) => {
    if (error) {
      res.status(500).send(error)
    } else if (ventas) {
      res.send(ventas)
    } else {
      res.status(404).send({})
    }
  })
}

module.exports = { createVenta, deleteVenta, getVenta }
