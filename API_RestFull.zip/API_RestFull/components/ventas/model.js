const mongoose = require('mongoose')
var clients = mongoose.model('clients')

const Venta = mongoose.model('ventas', { fecha: Date, total: Number, idCliente: [{
    type: mongoose.Schema.Types.ObjectId,
    ref:'clients'
    }],
});

module.exports = Venta;

