const express = require('express')
const router = express.Router()
const { createVenta, deleteVenta, getVenta } = require('./actions')

// GET ventas
router.get('/', getVenta)

// POST Create a Venta
router.post('/', createVenta)

// PUT Update a Venta's info
router.put('/:id', (req, res) => {
  res.send({})
})

// DELETE by ID
router.delete('/:id', deleteVenta)

module.exports = router